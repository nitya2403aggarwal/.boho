document.getElementById('purchaseForm').addEventListener('submit', function(event) {
    event.preventDefault();

    const vendorName = document.getElementById('vendorName').value.toUpperCase(); /* Capitalize input values */
    const productName = document.getElementById('productName').value.toUpperCase();
    const purchasedDate = document.getElementById('purchasedDate').value.toUpperCase();
    const quantity = document.getElementById('quantity').value;
    const price = document.getElementById('price').value;

    const tableBody = document.querySelector('#purchaseTable tbody');
    const newRow = tableBody.insertRow();
    newRow.innerHTML = `
        <td>${vendorName}</td>
        <td>${productName}</td>
        <td>${purchasedDate}</td>
        <td>${quantity}</td>
        <td>${price}</td>
    `;

    // Clear form fields after submission
    document.getElementById('purchaseForm').reset();
});